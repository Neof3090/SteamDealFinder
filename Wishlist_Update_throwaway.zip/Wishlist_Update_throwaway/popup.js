// popup.js
//
// RULE: popup.js should only handle UI.
// It asks background.js for deals and renders them.

const listEl = document.getElementById("dealList");
const statusEl = document.getElementById("status");

const steamIdBtn = document.getElementById("steamIdBtn")
const searchBtn = document.getElementById("search");

// Filters
const maxPriceInput = document.getElementById("maxPrice");
const maxDealsInput = document.getElementById("maxDeals");
const sortByInput = document.getElementById("sortBy");
const steam64IdInput = document.getElementById("steamId");
//const currencyInput = document.getElementById("currency");

// Simple HTML escaping to prevent XSS.
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[c]));
}

// Render list of deals into the popup.
function renderDeals(deals) {
  listEl.innerHTML = "";

  for (const d of deals) {
    const li = document.createElement("li");
    li.className = "item";

    const normalPrice = escapeHtml(d.normalPrice + " USD");
    const salePrice = escapeHtml(d.salePrice + " USD");

    const savings = Number(d.savings || 0).toFixed(0);
    li.innerHTML = `
        <div class="title">
            <a
                href="https://store.steampowered.com/app/${escapeHtml(d.steamAppID)}"
                target="_blank"
                rel="noopener noreferrer"
            >
                ${escapeHtml(d.title || "Untitled")}
            </a>
            </div>
        <div class="meta">
            <span class="badge">${savings}% off</span>
            <span>${escapeHtml(normalPrice)} → ${escapeHtml(salePrice)}</span>
        </div>
    `;

    listEl.appendChild(li);
  }
}

function clamp01(x) { return Math.max(0, Math.min(1, x)); }
function norm(x, min, max) {
  if (!isFinite(x) || max <= min) return 0;
  return clamp01((x - min) / (max - min));
}

const WEIGHTS = { savings: 0.35, rating: 0.25, meta: 0.10, price: 0.30 }; // (must add up to 1.0)
function scoreDeals(deals) {
  if (prices.length === 0) return deals.map(d => ({ ...d, _score: 0 }));
  
  // Compute ranges from the returned dataset (dynamic, simple)
  const prices = deals.map(d => Number(d.salePrice)).filter(Number.isFinite);
  const minP = Math.min(...prices);
  const maxP = Math.max(...prices);
  
  return deals.map(d => {
    const savings = Number(d.savings);            
    const dealRating = Number(d.dealRating);      
    const meta = Number(d.metacriticScore);       // (may be missing)
    const price = Number(d.salePrice);

    const S = norm(savings, 0, 100);
    const R = norm(dealRating, 0, 10);
    const M = norm(meta, 0, 100);

    // Lower price = better => invert normalized price
    const P = 1 - norm(price, minP, maxP);

    // Handle missing values: if meta/dealRating missing, they contribute 0
    const score =
      WEIGHTS.savings * S +
      WEIGHTS.rating  * R +
      WEIGHTS.meta    * M +
      WEIGHTS.price   * P;

    return { ...d, _score: score };
  });
}

function parseWishlistDocument(doc = document) {
    const items = [];

    for (const node of doc.querySelectorAll('[data-rfd-draggable-id^="WishlistItem-"]')) {
        const dragId = node.getAttribute('data-rfd-draggable-id') || '';
        const appIdFromDrag = dragId.match(/^WishlistItem-(\d+)-/)?.[1] || null;

        const titleLink = node.querySelector('a[href*="/app/"]');
        const href = titleLink?.href || '';
        const appIdFromHref = href.match(/\/app\/(\d+)\//)?.[1] || null;

        const appId = appIdFromHref || appIdFromDrag;
        if (!appId) continue;

        const title = node.querySelector('a.pOyXxbQoV38-')?.textContent?.trim()
            || titleLink?.textContent?.trim()
            || null;

        const rank = Number(node.querySelector('input[type="text"]')?.value || NaN);

        const priceTexts = [...node.querySelectorAll('div')]
            .map(el => el.textContent?.trim())
            .filter(Boolean);

        const discountText = priceTexts.find(t => /^-\d+%$/.test(t)) || null;

        const euroPrices = priceTexts.filter(t => /^\d+[.,]\d{2}€$/.test(t));

        let originalPrice = null;
        let finalPrice = null;

        if (discountText && euroPrices.length >= 2) {
            originalPrice = euroPrices[0];
            finalPrice = euroPrices[1];
        } else if (euroPrices.length >= 1) {
            finalPrice = euroPrices[0];
        }

        items.push({
            appId,
            title,
            rank: Number.isFinite(rank) ? rank : null,
            url: href || `https://store.steampowered.com/app/${appId}/`,
            discount: discountText,
            originalPrice,
            finalPrice
        });
    }

    return items;
}

async function fetchWishlist(steam64Id) {
    const url = `https://steamcommunity.com/profiles/${steam64Id}/wishlist/`;

    console.log("URL:", url);

    const res = await fetch(url);

    console.log("Status:", res.status, res.statusText);

    const text = await res.text();
    console.log("Raw response:", text);

    if (!res.ok) {
        throw new Error(`Wishlist fetch failed: ${res.status}`);
    }

    let data;
    try {
        data = JSON.parse(text);
    } catch (err) {
        console.error("JSON parse failed:", err);
        throw err;
    }

    return Object.entries(data)
        .sort((a, b) => (a[1].priority ?? 999) - (b[1].priority ?? 999))
        .map(([appId]) => appId);
}
// Request deals from background.js
async function requestDeals() {
  
  console.log("Requesting deals from background.js");
  
  statusEl.textContent = "Loading...";
  
  const maxPrice = maxPriceInput.value;
  const maxDeals = maxDealsInput.value;
  const sortBy = sortByInput.value;
  const steam64Id = steam64IdInput.value.trim();
  
  const msgType = "GET_DEALS";
  
  chrome.runtime.sendMessage(
    { 
      type: msgType,
      steam64Id: steam64Id,
      maxPrice: maxPrice,
      maxDeals: maxDeals,
      sortBy: sortBy
    },
    (resp) => 
    {
      if (!resp || !resp.ok) {
      statusEl.textContent = `Error: ${resp?.error || "unknown"}`;
      return;
      }

      statusEl.textContent = `Showing ${resp.deals.length} deals`;
      
      renderDeals(resp.deals);
    }
  );
}

function saveLocally(key, elementId) {
  const value = document.getElementById(elementId).value.trim();
  chrome.storage.local.set({ [key]: value });
}

// Initial load when popup opens
//requestDeals();

// On-load gathering local variables
chrome.storage.local.get("steam64Id", ({ steam64Id: savedId }) => {
    if (savedId) document.getElementById("steamId").value = savedId;
});

// Other on-load prerequisites
document.getElementById("steamIdHelp").addEventListener("click", (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: "https://steamid.io" });
}); 

// Buttons
steamIdBtn.addEventListener("click", () => saveLocally("steam64Id", "steamId"))
searchBtn.addEventListener("click", () => requestDeals());

// Input filters change
maxPriceInput.addEventListener("input", () => {
  const val = maxPriceInput.value;
  document.getElementById("maxPriceValue").textContent = val;
});
maxDealsInput.addEventListener("input", () => {
  const val = maxDealsInput.value;
  document.getElementById("maxDealsValue").textContent = val;
});